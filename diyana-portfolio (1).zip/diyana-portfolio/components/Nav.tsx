import { profile } from "@/data/content";

const links = [
  ["Projects", "#projects"],
  ["Experience", "#experience"],
  ["Skills", "#skills"],
  ["Contact", "#contact"],
];

export default function Nav() {
  return (
    <header className="sticky top-0 z-20 border-b border-stone-200/70 bg-[var(--bg)]/80 backdrop-blur dark:border-stone-800/70">
      <nav className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3">
        <a href="#top" className="font-mono text-sm font-semibold">
          {profile.name.split(" ")[0]}
          <span className="text-emerald-600 dark:text-emerald-400">.dev</span>
        </a>
        <ul className="hidden gap-6 text-sm sm:flex">
          {links.map(([label, href]) => (
            <li key={href}>
              <a
                href={href}
                className="text-stone-600 transition-colors hover:text-emerald-600 dark:text-stone-400 dark:hover:text-emerald-400"
              >
                {label}
              </a>
            </li>
          ))}
        </ul>
        <a
          href="#contact"
          className="rounded-full bg-emerald-600 px-4 py-1.5 text-sm font-medium text-white transition hover:bg-emerald-700 sm:hidden"
        >
          Contact
        </a>
      </nav>
    </header>
  );
}
