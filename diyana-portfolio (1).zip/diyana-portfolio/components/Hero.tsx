import { profile } from "@/data/content";

export default function Hero() {
  return (
    <section id="top" className="mx-auto max-w-5xl px-5 pb-16 pt-20 sm:pt-28">
      <p className="animate-fade-up font-mono text-sm text-emerald-600 dark:text-emerald-400">
        &gt; hello, I&apos;m
      </p>
      <h1
        className="animate-fade-up mt-3 text-4xl font-bold tracking-tight sm:text-6xl"
        style={{ animationDelay: "80ms" }}
      >
        {profile.name}
      </h1>
      <p
        className="animate-fade-up mt-4 text-lg font-medium text-stone-700 dark:text-stone-300 sm:text-xl"
        style={{ animationDelay: "160ms" }}
      >
        {profile.title}
      </p>
      <p
        className="animate-fade-up mt-4 max-w-2xl text-stone-600 dark:text-stone-400"
        style={{ animationDelay: "240ms" }}
      >
        {profile.tagline}
      </p>
      <div
        className="animate-fade-up mt-8 flex flex-wrap gap-3"
        style={{ animationDelay: "320ms" }}
      >
        <a
          href="#projects"
          className="rounded-full bg-emerald-600 px-6 py-2.5 text-sm font-medium text-white transition hover:-translate-y-0.5 hover:bg-emerald-700"
        >
          View projects
        </a>
        <a
          href={`mailto:${profile.email}`}
          className="rounded-full border border-stone-300 px-6 py-2.5 text-sm font-medium transition hover:-translate-y-0.5 hover:border-emerald-600 hover:text-emerald-600 dark:border-stone-700 dark:hover:border-emerald-400 dark:hover:text-emerald-400"
        >
          Email me
        </a>
      </div>
    </section>
  );
}
