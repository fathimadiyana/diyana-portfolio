import Section, { Chip } from "./Section";
import { projects } from "@/data/content";

export default function Projects() {
  const featured = projects.filter((p) => p.featured);
  const others = projects.filter((p) => !p.featured);

  return (
    <Section id="projects" eyebrow="01 / work" title="Featured projects">
      <div className="grid gap-5 sm:grid-cols-2">
        {featured.map((p, i) => (
          <article
            key={p.name}
            className={`group rounded-2xl border border-stone-200 bg-white/60 p-6 transition hover:-translate-y-1 hover:border-emerald-500 hover:shadow-lg dark:border-stone-800 dark:bg-stone-900/50 dark:hover:border-emerald-400 ${
              i === 0 ? "sm:col-span-2" : ""
            }`}
          >
            <p className="font-mono text-xs text-emerald-600 dark:text-emerald-400">
              {p.tag}
            </p>
            <h3 className="mt-2 text-lg font-semibold">{p.name}</h3>
            <p className="mt-2 text-sm leading-relaxed text-stone-600 dark:text-stone-400">
              {p.summary}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {p.tech.map((t) => (
                <Chip key={t}>{t}</Chip>
              ))}
            </div>
          </article>
        ))}
      </div>

      {others.length > 0 && (
        <div className="mt-6">
          <p className="mb-3 font-mono text-xs uppercase tracking-widest text-stone-500">
            Also built
          </p>
          {others.map((p) => (
            <div
              key={p.name}
              className="flex flex-col gap-2 rounded-xl border border-dashed border-stone-300 p-4 dark:border-stone-700 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <h3 className="font-medium">{p.name}</h3>
                <p className="text-sm text-stone-600 dark:text-stone-400">
                  {p.summary}
                </p>
              </div>
              <div className="flex gap-2">
                {p.tech.map((t) => (
                  <Chip key={t}>{t}</Chip>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </Section>
  );
}
