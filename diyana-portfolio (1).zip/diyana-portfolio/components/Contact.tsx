import Section from "./Section";
import { profile } from "@/data/content";

export default function Contact() {
  const links = [
    { label: "Email", value: profile.email, href: `mailto:${profile.email}` },
    {
      label: "Phone",
      value: profile.phone,
      href: `tel:${profile.phone.replace(/\s/g, "")}`,
    },
    { label: "LinkedIn", value: "Profile", href: profile.linkedin },
    { label: "GitHub", value: "Profile", href: profile.github },
  ].filter((l) => l.href);

  return (
    <Section id="contact" eyebrow="05 / contact" title="Let's talk">
      <p className="max-w-xl text-stone-600 dark:text-stone-400">
        I&apos;m preparing for fresher internship roles in data analysis, machine
        learning and business analysis. Reach out any time.
      </p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {links.map((l) => (
          <a
            key={l.label}
            href={l.href}
            target={l.href.startsWith("http") ? "_blank" : undefined}
            rel="noreferrer"
            className="rounded-xl border border-stone-200 p-4 transition hover:-translate-y-0.5 hover:border-emerald-500 dark:border-stone-800 dark:hover:border-emerald-400"
          >
            <span className="font-mono text-xs text-emerald-600 dark:text-emerald-400">
              {l.label}
            </span>
            <span className="block break-all font-medium">{l.value}</span>
          </a>
        ))}
      </div>
      <footer className="mt-16 text-xs text-stone-500">
        © {new Date().getFullYear()} {profile.name}
      </footer>
    </Section>
  );
}
