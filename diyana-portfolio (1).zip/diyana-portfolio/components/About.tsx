import Section from "./Section";
import { profile } from "@/data/content";

export default function About() {
  return (
    <Section id="about" eyebrow="about" title="About me">
      <div className="max-w-2xl space-y-4 text-stone-700 dark:text-stone-300">
        {profile.about.map((p) => (
          <p key={p}>{p}</p>
        ))}
      </div>
    </Section>
  );
}
