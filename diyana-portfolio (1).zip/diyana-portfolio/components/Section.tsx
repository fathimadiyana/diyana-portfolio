export default function Section({
  id,
  eyebrow,
  title,
  children,
}: {
  id: string;
  eyebrow: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="mx-auto max-w-5xl scroll-mt-16 px-5 py-14">
      <p className="font-mono text-xs uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
        {eyebrow}
      </p>
      <h2 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">
        {title}
      </h2>
      <div className="mt-8">{children}</div>
    </section>
  );
}

export function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-md border border-stone-200 bg-stone-100/70 px-2 py-0.5 font-mono text-xs text-stone-700 dark:border-stone-800 dark:bg-stone-900/70 dark:text-stone-300">
      {children}
    </span>
  );
}
