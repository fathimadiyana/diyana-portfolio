import Section, { Chip } from "./Section";
import { skills } from "@/data/content";

export default function Skills() {
  return (
    <Section id="skills" eyebrow="03 / toolkit" title="Skills">
      <div className="grid gap-6 sm:grid-cols-2">
        {skills.map((g) => (
          <div key={g.group}>
            <h3 className="mb-2 text-sm font-semibold">{g.group}</h3>
            <div className="flex flex-wrap gap-2">
              {g.items.map((s) => (
                <Chip key={s}>{s}</Chip>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}
