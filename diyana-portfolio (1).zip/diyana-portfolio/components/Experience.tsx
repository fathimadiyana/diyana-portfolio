import Section from "./Section";
import { experience, hackathons } from "@/data/content";

export default function Experience() {
  return (
    <Section id="experience" eyebrow="02 / experience" title="Internships & hackathons">
      <ol className="relative space-y-8 border-l border-stone-300 pl-6 dark:border-stone-700">
        {experience.map((e) => (
          <li key={e.org} className="relative">
            <span className="absolute -left-[31px] top-1.5 h-2.5 w-2.5 rounded-full bg-emerald-600 dark:bg-emerald-400" />
            <div className="flex flex-wrap items-baseline justify-between gap-x-4">
              <h3 className="font-semibold">
                {e.role} <span className="font-normal text-stone-500">· {e.org}</span>
              </h3>
              {e.period && (
                <span className="font-mono text-xs text-stone-500">{e.period}</span>
              )}
            </div>
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-stone-600 dark:text-stone-400">
              {e.points.map((p) => (
                <li key={p}>{p}</li>
              ))}
            </ul>
          </li>
        ))}
      </ol>

      <h3 className="mb-4 mt-14 font-mono text-xs uppercase tracking-widest text-stone-500">
        Hackathons & workshops
      </h3>
      <div className="grid gap-4 sm:grid-cols-2">
        {hackathons.map((h) => (
          <div
            key={h.name}
            className="rounded-xl border border-stone-200 p-4 transition hover:border-emerald-500 dark:border-stone-800 dark:hover:border-emerald-400"
          >
            <h4 className="font-medium">{h.name}</h4>
            <p className="font-mono text-xs text-emerald-600 dark:text-emerald-400">
              {h.event}
            </p>
            <p className="mt-2 text-sm text-stone-600 dark:text-stone-400">{h.text}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}
