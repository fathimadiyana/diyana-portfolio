import Section from "./Section";
import { education, certifications, leadership } from "@/data/content";

export default function Education() {
  return (
    <Section id="education" eyebrow="04 / learning" title="Education & certifications">
      <div className="rounded-2xl border border-stone-200 p-6 dark:border-stone-800">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h3 className="font-semibold">{education.degree}</h3>
          <span className="font-mono text-xs text-stone-500">{education.period}</span>
        </div>
        <p className="mt-1 text-sm">{education.school}</p>
        <p className="text-sm text-stone-500">{education.note}</p>
        <p className="mt-3 text-sm text-stone-600 dark:text-stone-400">
          {education.earlier}
        </p>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {certifications.map((c) => (
          <details
            key={c.issuer}
            className="group rounded-xl border border-stone-200 p-4 open:border-emerald-500 dark:border-stone-800 dark:open:border-emerald-400"
          >
            <summary className="flex cursor-pointer list-none items-baseline justify-between">
              <span className="font-medium">{c.issuer}</span>
              <span className="font-mono text-xs text-stone-500">{c.when}</span>
            </summary>
            <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-stone-600 dark:text-stone-400">
              {c.items.map((i) => (
                <li key={i}>{i}</li>
              ))}
            </ul>
          </details>
        ))}
      </div>

      <h3 className="mb-3 mt-12 font-mono text-xs uppercase tracking-widest text-stone-500">
        Leadership
      </h3>
      <ul className="space-y-2 text-sm text-stone-600 dark:text-stone-400">
        {leadership.map((l) => (
          <li key={l}>— {l}</li>
        ))}
      </ul>
    </Section>
  );
}
