export const profile = {
  name: "Fathima Diyana C H",
  title: "Machine Learning & Data Science | Full-Stack Developer",
  tagline:
    "Final-year IT student building AI-driven solutions with Python, computer vision and Flask, backed by four internships.",
  email: "diyanaernad@gmail.com",
  phone: "+91 9400436068",
  // Add your real profile URLs here. Entries with an empty url are hidden.
  linkedin: "https://www.linkedin.com/in/fathima-diyana-c-h-949036348",
  github: "https://github.com/me50/fathimadiyana",
  about: [
    "I'm a final-year B.Tech Information Technology student with hands-on experience in machine learning, data science and full-stack development, gained through four internships.",
    "I work with Python, SQL, Flask, computer vision and data visualization, and I build AI-driven solutions through hackathons and projects, from a video-detection model to a full-stack monitoring system for Southern Railway.",
  ],
};

export type Project = {
  name: string;
  summary: string;
  tech: string[];
  tag: string;
  featured?: boolean;
};

export const projects: Project[] = [
  {
    name: "Digital Performance Monitoring System (DPMS)",
    tag: "Full-stack · Southern Railway",
    summary:
      "Full-stack web application for Southern Railway with authentication, role-based access, performance monitoring and workflow management. Built by a team of five during my internship.",
    tech: ["Flask", "PostgreSQL", "SQLAlchemy", "Jinja", "Supabase"],
    featured: true,
  },
  {
    name: "AI-Generated Video Detection System",
    tag: "Computer vision · Deep learning",
    summary:
      "Classifies videos as AI-generated or authentic using computer vision.",
    tech: ["Python", "OpenCV", "Deep Learning"],
    featured: true,
  },
  {
    name: "REMEM",
    tag: "AI cognitive care platform",
    summary:
      "AI cognitive memory assistance platform offering memory support and caregiver assistance for cognitive care.",
    tech: ["AI", "ML"],
    featured: true,
  },
  {
    name: "SPLYCE",
    tag: "Mobile · Collaborative platform",
    summary:
      "Collaborative group service and expense splitter integrating group expense management, peer-to-peer services, shared inventory tracking and intelligent debt settlement.",
    tech: ["Flutter", "Firebase", "Google ML Kit"],
    featured: true,
  },
  {
    name: "Bus Reservation Management System",
    tag: "Database system",
    summary: "Database system managing buses, routes and reservations.",
    tech: ["PHP", "MySQL"],
  },
];

export const experience = [
  {
    role: "IT Intern",
    org: "Southern Railway, Divisional Office, Palakkad",
    period: "May – Jun 2026",
    points: [
      "Part of a team of five building a Digital Performance Monitoring System (DPMS) to digitize performance-monitoring workflows.",
      "Worked across requirements, development and system integration.",
    ],
  },
  {
    role: "Machine Learning Intern",
    org: "Cognifyz Technologies",
    period: "May – Jun 2026",
    points: [
      "Applied Python and ML techniques for data preprocessing and model development.",
    ],
  },
  {
    role: "Machine Learning Intern",
    org: "SkillCraft Technology",
    period: "May – Jun 2026",
    points: [
      "Built ML solutions using Python, predictive modeling and performance evaluation.",
    ],
  },
  {
    role: "Data Science Intern",
    org: "Techmaghi",
    period: "",
    points: [
      "Performed EDA and data visualization in Python to identify patterns and insights.",
    ],
  },
];

export const skills: { group: string; items: string[] }[] = [
  {
    group: "Languages",
    items: ["Python", "Java", "C", "SQL", "JavaScript"],
  },
  {
    group: "ML & Data",
    items: [
      "Data Preprocessing",
      "EDA",
      "Computer Vision",
      "Deep Learning",
      "NumPy",
      "Pandas",
      "Scikit-learn",
      "OpenCV",
      "TensorFlow",
    ],
  },
  {
    group: "Generative AI",
    items: ["Generative AI", "Prompt Engineering"],
  },
  {
    group: "Web & Backend",
    items: ["Flask", "SQLAlchemy", "Node.js", "HTML", "CSS", "PHP"],
  },
  {
    group: "Databases",
    items: ["PostgreSQL", "MySQL", "Supabase"],
  },
  {
    group: "Tools",
    items: ["Git", "GitHub", "VS Code"],
  },
];

export const education = {
  degree: "B.Tech, Information Technology",
  school: "Government Engineering College, Sreekrishnapuram",
  note: "APJ Abdul Kalam Technological University · Kerala, India",
  period: "Expected 2027",
  earlier: "Higher Secondary (Computer Science), GGVHSS Wandoor · 97% · NSS Leader",
};

export const hackathons = [
  {
    name: "TabMind",
    event: "TinkerHub Women Hackathon",
    text: "Built an AI browser tool to organize and retrieve information across tabs in a time-boxed team build.",
  },
  {
    name: "Smart India Hackathon 2026",
    event: "Internal Round · IEDC & µLearn, GEC Palakkad",
    text: "Participated in the institute-level selection round of India's national innovation hackathon.",
  },
  {
    name: "INVENTO'26 UI/UX Workshop",
    event: "PACELAB, GEC Palakkad · Jan 2026",
    text: "Hands-on training in user research and interface design.",
  },
  {
    name: "Cybersecurity Virtual Program",
    event: "Simulation",
    text: "Completed a simulation analyzing threat scenarios and proposing mitigation strategies.",
  },
];

export const certifications = [
  {
    issuer: "Anthropic",
    when: "Apr 2026",
    items: [
      "Claude 101",
      "Claude Code 101",
      "Introduction to Claude Cowork",
      "AI Fluency for Nonprofits",
    ],
  },
  {
    issuer: "Google (Coursera)",
    when: "Jul 2026",
    items: [
      "Google AI Essentials (5-course specialization)",
      "Google Prompting Essentials (4-course specialization)",
    ],
  },
  {
    issuer: "Microsoft Learn",
    when: "28 badges",
    items: [
      "Generative AI: Copilot, image generation, prompt design",
      "AI concepts: RAG, information extraction, computer vision, speech, NLP, ML",
      "Azure AI Foundry: fine-tuning, RAG, prompt flow, SDK, deployment",
      "Azure & cloud fundamentals: architecture, monitoring, governance, cost, Entra ID",
    ],
  },
  {
    issuer: "LinkedIn Learning",
    when: "Nov 2025",
    items: [
      "Python for Students",
      "HTML Essential Training",
      "Node.js Essential Training",
      "REST APIs, Vectors & AI in SQL Server 2025",
      "Prompt Engineering: How to Talk to the AIs",
    ],
  },
  {
    issuer: "Others",
    when: "",
    items: [
      "1 Million Prompters (Dubai Future Foundation)",
      "Data Science (Techmaghi)",
      "ML (Cognifyz)",
      "ML (SkillCraft)",
      "NPTEL/SWAYAM",
      "Cloud Computing",
    ],
  },
];

export const leadership = [
  "Founder, LARA: led branding, business development and product growth",
  "Chairperson, GEC Fashion Club",
  "NSS Leader, GGVHSS Wandoor",
];
